/**
 * Navigation Scripts
 * Handle mobile menu toggle
 */

(function() {
    'use strict';

    // Mobile Menu Toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const primaryMenuWrapper = document.querySelector('.primary-menu-wrapper');

    if (menuToggle && primaryMenuWrapper) {
        menuToggle.addEventListener('click', function() {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            
            // Toggle aria-expanded
            this.setAttribute('aria-expanded', !isExpanded);
            
            // Toggle active class
            primaryMenuWrapper.classList.toggle('active');
        });
    }

    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.site-header')) {
            if (primaryMenuWrapper && primaryMenuWrapper.classList.contains('active')) {
                primaryMenuWrapper.classList.remove('active');
                if (menuToggle) {
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            }
        }
    });

    // Close mobile menu on window resize to desktop
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            if (window.innerWidth > 800) {
                if (primaryMenuWrapper && primaryMenuWrapper.classList.contains('active')) {
                    primaryMenuWrapper.classList.remove('active');
                    if (menuToggle) {
                        menuToggle.setAttribute('aria-expanded', 'false');
                    }
                }
            }
        }, 250);
    });

})();

