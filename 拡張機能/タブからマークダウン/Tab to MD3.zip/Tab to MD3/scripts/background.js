// Background service worker for Tab to MD extension

chrome.runtime.onInstalled.addListener(() => {
  console.log('Tab to MD extension installed');
});

// タブの内容を取得してマークダウンに変換
async function convertTabToMarkdown(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    
    // アクセスできないページ（chrome://, chrome-extension://, about:など）をチェック
    if (!tab.url || tab.url.startsWith('chrome://') || 
        tab.url.startsWith('chrome-extension://') || 
        tab.url.startsWith('moz-extension://') ||
        tab.url.startsWith('about:') ||
        tab.url.startsWith('edge://')) {
      // アクセスできないページの場合は、タブ情報のみを使用
      return formatAsMarkdown(tab, {
        title: tab.title || 'Unknown',
        url: tab.url || '',
        content: 'このページの内容にはアクセスできません。\n（chrome://、chrome-extension://、about:などの特殊なページは保護されています）'
      });
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: extractPageContent
    });

    if (results && results[0] && results[0].result) {
      const content = results[0].result;
      return formatAsMarkdown(tab, content);
    }
    return null;
  } catch (error) {
    // エラーの場合でも、タブ情報のみを使用してマークダウンを生成
    try {
      const tab = await chrome.tabs.get(tabId);
      return formatAsMarkdown(tab, {
        title: tab.title || 'Unknown',
        url: tab.url || '',
        content: `エラー: このページの内容を取得できませんでした。\n${error.message}`
      });
    } catch (e) {
      console.error('Error converting tab to markdown:', error);
      return null;
    }
  }
}

// ページの内容を抽出
function extractPageContent() {
  return {
    title: document.title,
    url: window.location.href,
    content: document.body.innerText || document.body.textContent || ''
  };
}

// マークダウン形式にフォーマット
function formatAsMarkdown(tab, pageContent) {
  const timestamp = new Date().toISOString();
  return `# ${pageContent.title || tab.title}

**URL:** ${pageContent.url || tab.url}  
**取得日時:** ${timestamp}

---

${pageContent.content}

`;
}

// メッセージハンドラー
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'convertTab') {
    convertTabToMarkdown(request.tabId)
      .then(markdown => {
        sendResponse({ success: true, markdown });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true; // 非同期レスポンスのため
  }
});

export { convertTabToMarkdown, formatAsMarkdown };

