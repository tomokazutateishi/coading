// Settings script for Tab to MD extension

const includeTimestamp = document.getElementById('includeTimestamp');
const includeUrl = document.getElementById('includeUrl');
const defaultFilename = document.getElementById('defaultFilename');
const defaultFolder = document.getElementById('defaultFolder');
const selectFolderBtn = document.getElementById('selectFolderBtn');
const clearFolderBtn = document.getElementById('clearFolderBtn');
const saveBtn = document.getElementById('saveBtn');
const statusDiv = document.getElementById('status');

// 要素が存在するか確認（早期リターン）
if (!selectFolderBtn || !clearFolderBtn || !defaultFolder || !saveBtn || !statusDiv) {
  console.error('Required elements not found. Please check the HTML structure.');
  // 必須要素が存在しない場合は処理を中断
  if (statusDiv) {
    statusDiv.textContent = '✗ エラー: 必要な要素が見つかりません';
    statusDiv.style.color = '#dc3545';
  }
  // イベントリスナーを追加できないため、ここで終了
  // ただし、他の要素が存在する可能性があるため、個別にチェック
}

let folderSelectionInProgress = false;
let selectedFolderInfo = null;

function normalizeRelativePath(path) {
  if (!path) {
    return '';
  }
  const normalizedSeparators = path.replace(/\\/g, '/');
  const trimmed = normalizedSeparators.replace(/^\/+|\/+$/g, '');
  if (!trimmed) {
    return '';
  }
  return trimmed
    .split('/')
    .filter((segment) => segment.length > 0)
    .join('/');
}

function createDownloadsFolderInfo(relativePath = '') {
  const normalized = normalizeRelativePath(relativePath);
  return {
    type: 'downloads',
    relativePath: normalized,
    absolutePath: '',
    displayPath: normalized ? `ダウンロード/${normalized}` : 'ダウンロードフォルダ（直下）'
  };
}

function createAbsoluteFolderInfo(absolutePath = '') {
  const normalized = absolutePath.replace(/\\/g, '/').replace(/\/+$/g, '');
  let display = normalized;

  if (normalized) {
    const macHomeMatch = normalized.match(/^\/Users\/[^/]+(\/.*)?$/);
    if (macHomeMatch) {
      const suffix = macHomeMatch[1] || '';
      display = suffix ? `~${suffix}` : '~';
    } else {
      display = normalized;
    }
  } else {
    display = '（選択されたフォルダなし）';
  }

  return {
    type: 'absolute',
    relativePath: '',
    absolutePath: normalized,
    displayPath: display
  };
}

function inferFolderInfo(storedValue) {
  if (!storedValue) {
    return null;
  }

  if (typeof storedValue === 'string') {
    return createDownloadsFolderInfo(storedValue);
  }

  if (typeof storedValue === 'object') {
    if (storedValue.type === 'absolute') {
      return createAbsoluteFolderInfo(storedValue.absolutePath || storedValue.path || '');
    }

    const info = createDownloadsFolderInfo(storedValue.relativePath || storedValue.path || '');
    if (storedValue.displayPath) {
      info.displayPath = storedValue.displayPath;
    }
    return info;
  }

  return null;
}

function setFolderSelection(folderInfo) {
  selectedFolderInfo = folderInfo;
  if (defaultFolder) {
    defaultFolder.value = folderInfo ? folderInfo.displayPath : 'ダウンロードフォルダ（直下）';
  }
}

// 設定を読み込む
chrome.storage.sync.get(['includeTimestamp', 'includeUrl', 'defaultFilename', 'defaultFolder'], (result) => {
  if (result.includeTimestamp !== undefined) {
    includeTimestamp.checked = result.includeTimestamp;
  }
  if (result.includeUrl !== undefined) {
    includeUrl.checked = result.includeUrl;
  }
  if (result.defaultFilename) {
    defaultFilename.value = result.defaultFilename;
  }
  if (result.defaultFolder !== undefined) {
    setFolderSelection(inferFolderInfo(result.defaultFolder));
  }
});

// フォルダ選択ボタン
if (selectFolderBtn) {
  selectFolderBtn.addEventListener('click', async () => {
  try {
    folderSelectionInProgress = true;
    statusDiv.textContent = 'フォルダ選択ダイアログを開いています...';
    statusDiv.style.color = '#666';
    
    // ダミーファイルを作成してダウンロード
    const dummyContent = 'This is a dummy file for folder selection. You can delete this file.';
    const blob = new Blob([dummyContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    let downloadId;
    try {
      // ダウンロードを開始（ユーザーがフォルダを選択できるように）
      downloadId = await chrome.downloads.download({
        url: url,
        filename: '__FOLDER_SELECTION__.txt',
        saveAs: true
      });
    } catch (error) {
      // エラー時はURLを解放
      URL.revokeObjectURL(url);
      throw error;
    }
    
    // ダウンロード完了またはキャンセル時にURLを解放するためのリスナー
    const cleanupUrl = () => {
      URL.revokeObjectURL(url);
    };
    
    // ダウンロードイベントを監視
    const onChanged = (downloadDelta) => {
      if (downloadDelta.id === downloadId && downloadDelta.state) {
        if (downloadDelta.state.current === 'complete') {
          // ダウンロードが完了したら、ファイルパスからフォルダパスを抽出
          chrome.downloads.search({ id: downloadId }, (results) => {
            if (results && results[0] && results[0].filename) {
              const fullPath = results[0].filename;
              // ファイル名を除いてフォルダパスを取得
              const folderPath = fullPath.substring(0, fullPath.lastIndexOf('/'));
              // ダウンロードフォルダからの相対パスを計算
              extractRelativePath(folderPath, downloadId, cleanupUrl);
            }
          });
        } else if (downloadDelta.state.current === 'interrupted' || downloadDelta.state.current === 'cancelled') {
          folderSelectionInProgress = false;
          cleanupUrl();
          statusDiv.textContent = 'フォルダ選択がキャンセルされました';
          statusDiv.style.color = '#dc3545';
          setTimeout(() => {
            statusDiv.textContent = '';
          }, 2000);
          chrome.downloads.onChanged.removeListener(onChanged);
        }
      }
    };
    
    chrome.downloads.onChanged.addListener(onChanged);
    
    // タイムアウト処理（30秒後にリスナーを削除）
    setTimeout(() => {
      chrome.downloads.onChanged.removeListener(onChanged);
      folderSelectionInProgress = false;
      cleanupUrl();
    }, 30000);
    
  } catch (error) {
    folderSelectionInProgress = false;
    statusDiv.textContent = '✗ エラー: ' + error.message;
    statusDiv.style.color = '#dc3545';
    console.error('Error selecting folder:', error);
  }
  });
}

// 相対パスを抽出する関数
// fullPathは既にファイル名が除かれたフォルダパスです
// cleanupUrlはURLを解放するためのコールバック関数（オプション）
async function extractRelativePath(fullPath, downloadId, cleanupUrl = null) {
  try {
    const normalizedFullPath = fullPath.replace(/\\/g, '/');
    let folderInfo;

    if (normalizedFullPath.match(/\/Downloads\//i)) {
      const parts = normalizedFullPath.split(/\/Downloads\//i);
      const afterDownloads = parts[1] || '';
      folderInfo = createDownloadsFolderInfo(afterDownloads);
    } else if (/\/Downloads$/i.test(normalizedFullPath)) {
      folderInfo = createDownloadsFolderInfo('');
    } else {
      folderInfo = createAbsoluteFolderInfo(normalizedFullPath);
    }

    setFolderSelection(folderInfo);
    folderSelectionInProgress = false;
    
    // URLを解放
    if (cleanupUrl) {
      cleanupUrl();
    }
    
    // ダミーファイルを削除（非同期で実行、エラーは無視）
    chrome.downloads.removeFile(downloadId, () => {
      chrome.downloads.erase({ id: downloadId }, () => {
        console.log('Dummy file removed');
      });
    });
    
    statusDiv.textContent = '✓ フォルダが選択されました: ' + folderInfo.displayPath;
    statusDiv.style.color = 'green';
    setTimeout(() => {
      statusDiv.textContent = '';
    }, 3000);
    
  } catch (error) {
    folderSelectionInProgress = false;
    statusDiv.textContent = '✗ エラー: ' + error.message;
    statusDiv.style.color = '#dc3545';
    console.error('Error extracting relative path:', error);
  }
}

// クリアボタン
if (clearFolderBtn) {
  clearFolderBtn.addEventListener('click', () => {
    setFolderSelection(null);
    statusDiv.textContent = 'フォルダ選択をクリアしました';
    statusDiv.style.color = '#666';
    setTimeout(() => {
      statusDiv.textContent = '';
    }, 2000);
  });
}

// 設定を保存
if (saveBtn) {
  saveBtn.addEventListener('click', () => {
    const folderInfoToSave = selectedFolderInfo
      ? {
          type: selectedFolderInfo.type,
          relativePath: selectedFolderInfo.relativePath,
          absolutePath: selectedFolderInfo.absolutePath,
          displayPath: selectedFolderInfo.displayPath
        }
      : null;

    chrome.storage.sync.set({
      includeTimestamp: includeTimestamp.checked,
      includeUrl: includeUrl.checked,
      defaultFilename: defaultFilename.value,
      defaultFolder: folderInfoToSave
    }, () => {
      statusDiv.textContent = '✓ 設定を保存しました';
      statusDiv.style.color = 'green';
      setTimeout(() => {
        statusDiv.textContent = '';
      }, 2000);
    });
  });
}

