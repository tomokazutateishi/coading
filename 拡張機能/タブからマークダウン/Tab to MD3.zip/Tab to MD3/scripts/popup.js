// Popup script for Tab to MD extension

const convertBtn = document.getElementById('convertBtn');
const statusDiv = document.getElementById('status');
const currentFolderDiv = document.getElementById('currentFolder');
const settingsLink = document.getElementById('settingsLink');

// 設定ページを開く
settingsLink.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

// 設定を読み込む共通関数
async function loadSettings(keys) {
  return await chrome.storage.sync.get(keys);
}

function normalizeRelativePath(path) {
  if (!path) {
    return '';
  }
  const normalizedSeparators = path.replace(/\\/g, '/');
  const trimmed = normalizedSeparators.replace(/^\/+|\/+$/g, '');
  if (!trimmed) {
    return '';
  }
  return trimmed
    .split('/')
    .filter((segment) => segment.length > 0)
    .join('/');
}

function resolveFolderInfo(folderSetting) {
  if (!folderSetting) {
    return null;
  }

  if (typeof folderSetting === 'string') {
    return {
      type: 'downloads',
      relativePath: normalizeRelativePath(folderSetting),
      absolutePath: ''
    };
  }

  if (typeof folderSetting === 'object') {
    if (folderSetting.type === 'absolute') {
      return {
        type: 'absolute',
        relativePath: '',
        absolutePath: (folderSetting.absolutePath || folderSetting.path || '').replace(/\\/g, '/').replace(/\/+$/g, '')
      };
    }

    return {
      type: 'downloads',
      relativePath: normalizeRelativePath(folderSetting.relativePath || folderSetting.path || ''),
      absolutePath: ''
    };
  }

  return null;
}

function getFolderDisplayText(folderSetting) {
  if (folderSetting && typeof folderSetting === 'object' && folderSetting.displayPath) {
    return folderSetting.displayPath;
  }

  const info = resolveFolderInfo(folderSetting);
  if (!info) {
    return 'ダウンロードフォルダ（直下）';
  }

  if (info.type === 'absolute') {
    if (info.absolutePath) {
      const macHomeMatch = info.absolutePath.match(/^\/Users\/[^/]+(\/.*)?$/);
      if (macHomeMatch) {
        const suffix = macHomeMatch[1] || '';
        return suffix ? `~${suffix}` : '~';
      }
      return info.absolutePath;
    }
    return '（選択されたフォルダなし）';
  }

  return info.relativePath ? `ダウンロード/${info.relativePath}` : 'ダウンロードフォルダ（直下）';
}

function buildDownloadOptions(folderSetting, baseFileName) {
  const info = resolveFolderInfo(folderSetting);

  if (!info) {
    return {
      filename: baseFileName,
      saveAs: true
    };
  }

  if (info.type === 'absolute') {
    // Chromeのdownloads APIは絶対パスを受け付けないため、
    // ファイル名だけを指定してsaveAsダイアログを開く
    // ユーザーはダイアログで設定したフォルダを手動で選択する必要がある
    return {
      filename: baseFileName,
      saveAs: true
    };
  }

  const relativePath = info.relativePath;
  if (!relativePath) {
    return {
      filename: baseFileName,
      saveAs: true
    };
  }

  return {
    filename: `${relativePath}/${baseFileName}`,
    saveAs: true
  };
}

async function downloadMarkdown(content, filename) {
  const result = await loadSettings(['defaultFolder']);
  const folderSetting = result.defaultFolder;
  const baseFileName = `${filename}.md`;
  const downloadTarget = buildDownloadOptions(folderSetting, baseFileName);
  const info = resolveFolderInfo(folderSetting);

  // 絶対パスが設定されている場合、警告を表示
  if (info && info.type === 'absolute') {
    const folderPath = info.absolutePath || getFolderDisplayText(folderSetting);
    console.warn(`絶対パスが設定されています: ${folderPath}`);
    console.warn('Chrome拡張機能の制限により、保存ダイアログで手動でフォルダを選択する必要があります。');
  }

  const blob = new Blob([content], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);

  try {
    await chrome.downloads.download({
      url,
      filename: downloadTarget.filename,
      saveAs: downloadTarget.saveAs
    });
  } catch (error) {
    const errorMessage = chrome.runtime.lastError?.message || (error instanceof Error ? error.message : String(error));
    throw new Error(errorMessage);
  } finally {
    URL.revokeObjectURL(url);
  }
}

// 現在の保存フォルダを表示
async function updateFolderInfo() {
  const result = await loadSettings(['defaultFolder']);
  const folderSetting = result.defaultFolder;
  const displayText = getFolderDisplayText(folderSetting);
  const info = resolveFolderInfo(folderSetting);
  
  if (info && info.type === 'absolute') {
    // 絶対パスが設定されている場合、警告を表示
    currentFolderDiv.textContent = `保存先: ${displayText} ⚠️`;
    currentFolderDiv.setAttribute('aria-label', `現在の保存先: ${displayText}（注意: 保存ダイアログで手動でフォルダを選択する必要があります）`);
    currentFolderDiv.style.color = '#ff6b00';
  } else {
    currentFolderDiv.textContent = `保存先: ${displayText}`;
    currentFolderDiv.setAttribute('aria-label', `現在の保存先: ${displayText}`);
    currentFolderDiv.style.color = '';
  }
}

// ページ読み込み時にフォルダ情報を更新
updateFolderInfo();

// 現在のウィンドウのタブを変換（1ページ1ファイル）
convertBtn.addEventListener('click', async () => {
  try {
    statusDiv.textContent = '変換中...';
    
    // 現在のウィンドウのすべてのタブを取得
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    if (tabs.length === 0) {
      statusDiv.textContent = '✗ タブが見つかりません';
      return;
    }

    let successCount = 0;
    let errorCount = 0;

    // 各タブを1ファイルずつ変換・保存
    for (const tab of tabs) {
      try {
        const response = await chrome.runtime.sendMessage({
          action: 'convertTab',
          tabId: tab.id
        });

        if (response.success) {
          // ファイル名を安全にする（特殊文字を削除）
          const safeFilename = sanitizeFilename(tab.title || 'tab');
          await downloadMarkdown(response.markdown, safeFilename);
          successCount++;
        } else {
          errorCount++;
          console.error(`Failed to convert tab: ${tab.title}`, response.error);
        }
      } catch (error) {
        errorCount++;
        console.error(`Error converting tab: ${tab.title}`, error);
      }
    }

    // 結果を表示
    if (errorCount === 0) {
      statusDiv.textContent = `✓ ${successCount}個のタブを変換完了`;
    } else {
      statusDiv.textContent = `✓ ${successCount}個成功、${errorCount}個失敗`;
    }
    
    setTimeout(() => {
      statusDiv.textContent = '';
    }, 3000);
  } catch (error) {
    statusDiv.textContent = '✗ エラー: ' + error.message;
    console.error('Error:', error);
  }
});

// ファイル名を安全にする（特殊文字を削除・置換）
function sanitizeFilename(filename) {
  return filename
    .replace(/[<>:"/\\|?*]/g, '_') // 特殊文字をアンダースコアに置換
    .replace(/\s+/g, '_') // スペースをアンダースコアに置換
    .substring(0, 100); // 長すぎるファイル名を制限
}